INSERT INTO MOBILES (prodid, modelname, company, connectivity, ram, rom, color, screen, battery, processor, price, rating)
VALUES
(1, 'iPhone 12', 'Apple', '5G', '4GB', '64GB', 'Black', '6.1 inch', '2815mAh', 'A14 Bionic', 999.99, 4.3),
(2, 'Galaxy S21', 'Samsung', '5G', '8GB', '128GB', 'Phantom Violet', '6.2 inch', '4000mAh', 'Exynos 2100', 899.99, 4.3),
(3, 'Pixel 5', 'Google', '5G', '8GB', '128GB', 'Just Black', '6.0 inch', '4080mAh', 'Snapdragon 765G', 699.99, 4.3),
(4, 'OnePlus 9', 'OnePlus', '5G', '12GB', '256GB', 'Arctic Sky', '6.55 inch', '4500mAh', 'Snapdragon 888', 899.99, 4.3),
(5, 'Mi 11', 'Xiaomi', '5G', '8GB', '128GB', 'Midnight Gray', '6.81 inch', '4600mAh', 'Snapdragon 888', 799.99, 4.3),
(6, 'Galaxy Note 20 Ultra', 'Samsung', '5G', '12GB', '256GB', 'Mystic Bronze', '6.9 inch', '4500mAh', 'Exynos 990', 1299.99, 4.3),
(7, 'iPhone 13 Pro', 'Apple', '5G', '6GB', '128GB', 'Graphite', '6.1 inch', '3095mAh', 'A15 Bionic', 1199.99, 4.3),
(8, 'OnePlus 9 Pro', 'OnePlus', '5G', '12GB', '256GB', 'Morning Mist', '6.7 inch', '4500mAh', 'Snapdragon 888', 1099.99, 4.3),
(9, 'Mi 11 Ultra', 'Xiaomi', '5G', '12GB', '256GB', 'Ceramic Black', '6.81 inch', '5000mAh', 'Snapdragon 888', 1199.99, 4.3),
(10, 'Pixel 6 Pro', 'Google', '5G', '12GB', '256GB', 'Stormy Black', '6.7 inch', '5000mAh', 'Google Tensor', 1099.99, 4.3),
(11, 'Galaxy Z Fold 3', 'Samsung', '5G', '12GB', '256GB', 'Phantom Black', '7.6 inch', '4400mAh', 'Snapdragon 888', 1799.99, 4.3),
(12, 'iPhone SE', 'Apple', '4G', '3GB', '64GB', 'Product Red', '4.7 inch', '1821mAh', 'A13 Bionic', 399.99, 4.3),
(13, 'OnePlus 8 Pro', 'OnePlus', '5G', '8GB', '128GB', 'Glacial Green', '6.78 inch', '4510mAh', 'Snapdragon 865', 899.99, 4.3),
(14, 'Mi 11i', 'Xiaomi', '5G', '8GB', '128GB', 'Cosmic Black', '6.67 inch', '4520mAh', 'Snapdragon 888', 599.99, 4.3),
(15, 'Pixel 5a', 'Google', '5G', '6GB', '128GB', 'Mostly Black', '6.34 inch', '4680mAh', 'Snapdragon 765G', 499.99, 4.3);
