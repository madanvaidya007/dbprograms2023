CREATE TABLE MOBILES (
  prodid INT PRIMARY KEY,
  modelname VARCHAR(50),
  company VARCHAR(50),
  connectivity VARCHAR(5),
  ram VARCHAR(10),
  rom VARCHAR(10),
  color VARCHAR(20),
  screen VARCHAR(20),
  battery VARCHAR(20),
  processor VARCHAR(50),
  price DECIMAL(10,2),
  rating DECIMAL(3,1)
);
