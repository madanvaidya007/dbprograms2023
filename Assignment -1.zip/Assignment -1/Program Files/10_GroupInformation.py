import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

try:
    curs = con.cursor()
    curs.execute("SELECT company AS Brand, COUNT(DISTINCT modelname) AS TotalModels, AVG(price) AS AveragePrice, AVG(rating) AS AverageRating FROM MOBILES GROUP BY company")
    results = curs.fetchall()

    if results:
        print("Brand\tTotal Models\tAverage Price\tAverage Rating")
        for row in results:
            brand, total_models, average_price, average_rating = row
            print(f"{brand}\t{total_models}\t\t{average_price:.2f}\t\t{average_rating:.2f}")
    else:
        print("No data found.")

except Exception as e:
    print("Error retrieving group by information:", e)

con.close()
