import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

company = input("Enter the company name: ")
amount = float(input("Enter the amount to reduce the price by: "))

try:
    curs = con.cursor()
    curs.callproc("ReducePriceByAmount", (company, amount))
    con.commit()
    print("Price reduced successfully.")
except Exception as e:
    print("Error reducing price:", e)
    con.rollback()

con.close()
