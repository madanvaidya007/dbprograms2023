import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

field = input("Enter the field name (e.g., rom): ")

try:
    curs = con.cursor()
    curs.execute(f"SELECT * FROM MOBILES ORDER BY {field} DESC")
    results = curs.fetchall()

    if results:
        print("Prodid\tModel Name\tCompany\t\tConnectivity\tRAM\tROM\tColor\tScreen\tBattery\tProcessor\tPrice\tRating")
        for row in results:
            print("\t".join(str(value) for value in row))
    else:
        print("No data found.")

except Exception as e:
    print("Error retrieving mobiles:", e)

con.close()
