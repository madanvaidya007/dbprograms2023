import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

modelname = input("Enter the model name: ")
purpose = input("Enter the purpose: ")

try:
    curs = con.cursor()
    curs.execute("UPDATE MOBILES SET purpose = %s WHERE modelname = %s", (purpose, modelname))
    con.commit()
    print("Mobiles updated successfully.")
except Exception as e:
    print("Error updating mobiles:", e)
    con.rollback()

con.close()
