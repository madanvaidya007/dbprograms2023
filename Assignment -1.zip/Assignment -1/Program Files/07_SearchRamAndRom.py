import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

ram = int(input("Enter the RAM: "))
rom = int(input("Enter the ROM: "))

curs = con.cursor()
curs.execute("SELECT * FROM MOBILES WHERE ram = %s AND rom = %s", (ram, rom))
mobiles = curs.fetchall()

if mobiles:
    print("Mobiles with RAM:", ram, "and ROM:", rom)
    for mobile in mobiles:
        print("Product ID:", mobile[0])
        print("Model Name:", mobile[1])
        print("Company:", mobile[2])
        print("Connectivity:", mobile[3])
        print("RAM:", mobile[4])
        print("ROM:", mobile[5])
        print("Color:", mobile[6])
        print("Screen:", mobile[7])
        print("Battery:", mobile[8])
        print("Processor:", mobile[9])
        print("Price:", mobile[10])
        print("Rating:", mobile[11])
        print("------------------------")
else:
    print("No mobiles found with the specified RAM and ROM combination.")

con.close()
