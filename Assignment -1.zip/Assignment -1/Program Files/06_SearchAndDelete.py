import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

id = int(input("Enter The Prodid To search: "))

curs = con.cursor()
curs.execute("SELECT * FROM MOBILES WHERE prodid = %s", (id,))
data = curs.fetchone()

if data:
    print("Product ID:", data[0])
    print("Model Name:", data[1])
    print("Company:", data[2])
    print("Connectivity:", data[3])
    print("RAM:", data[4])
    print("ROM:", data[5])
    print("Color:", data[6])
    print("Screen:", data[7])
    print("Battery:", data[8])
    print("Processor:", data[9])
    print("Price:", data[10])
    print("Rating:", data[11])
    print("-------------------------------")

    confirm = input("Do You Want Delete (Yes / No): ")
    if confirm.lower() == 'yes':
        curs.execute("DELETE FROM MOBILES WHERE prodid = %s", (id,))
        con.commit()
        print("Deleted Successfully!!!")
        exit()
    else:
        print("Deletion Aborted.")
else:
    print("Product Not Found.")
