import pymysql

con=pymysql.connect(host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',user='ur4nyyssdveeh82x',password='IbCWhQGFEF3Y3y6UrofK',database='bgzyjlu3ft8fjsaftjlq')
print("succesfully coonected to cloud database")

# Get input from the user
prodid = int(input("Enter prodid: "))
modelname = input("Enter model name: ")
company = input("Enter company: ")
connectivity = input("Enter connectivity (4G/5G): ")
ram = input("Enter RAM: ")
rom = input("Enter ROM: ")
color = input("Enter color: ")
screen = input("Enter screen size: ")
battery = input("Enter battery capacity: ")
processor = input("Enter processor: ")
price = float(input("Enter price: "))
rating = float(input("Enter rating (0.0 to 5.0): "))

# SQL query to insert the new mobile data into the table
sql = "INSERT INTO MOBILES (prodid, modelname, company, connectivity, ram, rom, color, screen, battery, processor, price, rating) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
values = (prodid, modelname, company, connectivity, ram, rom, color, screen, battery, processor, price, rating)

try:
    cursor = con.cursor()
    cursor.execute(sql, values)
    con.commit()
    print("Mobile added successfully!")
except Exception as e:
    print("Error adding mobile:", e)
    con.rollback()

cursor.close()
con.close()
