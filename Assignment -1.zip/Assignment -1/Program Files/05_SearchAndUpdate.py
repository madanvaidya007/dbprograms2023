import pymysql

con = pymysql.connect(
    host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
    user='ur4nyyssdveeh82x',
    password='IbCWhQGFEF3Y3y6UrofK',
    database='bgzyjlu3ft8fjsaftjlq'
)

prodid = int(input("Enter the prodid: "))
new_price = float(input("Enter the new price: "))

curs = con.cursor()
curs.execute("SELECT * FROM MOBILES WHERE prodid = %s", (prodid,))
data = curs.fetchone()

if data:
    curs.execute("UPDATE MOBILES SET price = %s WHERE prodid = %s", (new_price, prodid))
    con.commit()
    print("Price updated successfully.")
else:
    print("Mobile does not exist.")

con.close()
