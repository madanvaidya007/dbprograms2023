import pymysql

con=pymysql.connect(host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',user='ur4nyyssdveeh82x',password='IbCWhQGFEF3Y3y6UrofK',database='bgzyjlu3ft8fjsaftjlq')
print("succesfully coonected to cloud database")


# Get the modelname from the user
modelname = input("Enter the model name: ")

# SQL query to search for the mobile
sql = "SELECT * FROM MOBILES WHERE modelname = %s"
value = (modelname)

try:
    curs = con.cursor()
    curs.execute(sql, value)
    mobile = curs.fetchone()

    # Check if the mobile is found
    if mobile:
        print("Product ID:", mobile[0])
        print("Model Name:", mobile[1])
        print("Company:", mobile[2])
        print("Connectivity:", mobile[3])
        print("RAM:", mobile[4])
        print("ROM:", mobile[5])
        print("Color:", mobile[6])
        print("Screen:", mobile[7])
        print("Battery:", mobile[8])
        print("Processor:", mobile[9])
        print("Price:", mobile[10])
        print("Rating:", mobile[11])
    else:
        print("Mobile not found.")

except Exception as e:
    print("Error searching for mobile:", e)

curs.close()
con.close()
