import pymysql

con = pymysql.connect(host='bgzyjlu3ft8fjsaftjlq-mysql.services.clever-cloud.com',
                      user='ur4nyyssdveeh82x', password='IbCWhQGFEF3Y3y6UrofK', database='bgzyjlu3ft8fjsaftjlq')
print("succesfully coonected to cloud database")

# Get the company name from the user
company = input("Enter the company name: ")

# SQL query to retrieve mobiles of the specified company in ascending order of price
sql = "SELECT * FROM MOBILES WHERE company = %s ORDER BY price ASC"
value = (company,)

try:
    cursor = con.cursor()
    cursor.execute(sql, value)
    mobiles = cursor.fetchall()

    # Check if mobiles are found
    if mobiles:
        print("Mobiles of", company, "category:")
        for mobile in mobiles:
            print("Product ID:", mobile[0])
            print("Model Name:", mobile[1])
            print("Company:", mobile[2])
            print("Connectivity:", mobile[3])
            print("RAM:", mobile[4])
            print("ROM:", mobile[5])
            print("Color:", mobile[6])
            print("Screen:", mobile[7])
            print("Battery:", mobile[8])
            print("Processor:", mobile[9])
            print("Price:", mobile[10])
            print("Rating:", mobile[11])
            print("-"*45)
    else:
        print("No mobiles found for the specified company.")

except:
    print("Error retrieving mobiles:", e)

cursor.close()
con.close()
