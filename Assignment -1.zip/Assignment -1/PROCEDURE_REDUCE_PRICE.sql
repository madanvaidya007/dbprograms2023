CREATE PROCEDURE ReducePriceByAmount (
    IN p_company VARCHAR(255),
    IN p_amount DECIMAL(10, 2)
)
BEGIN
    UPDATE MOBILES
    SET price = price - p_amount
    WHERE company = p_company;
END;
